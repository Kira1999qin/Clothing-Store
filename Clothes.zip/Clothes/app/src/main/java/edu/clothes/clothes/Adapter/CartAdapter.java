package edu.clothes.clothes.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

import edu.clothes.clothes.Model.CartItem;
import edu.clothes.clothes.R;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.CartViewHolder> {

    private List<CartItem> cartItems;
    private OnCartItemActionListener onCartItemActionListener;

    public interface OnCartItemActionListener {
        void onDeleteCartItem(CartItem cartItem);
        void onUpdateCartItemQuantity(CartItem cartItem, int newQuantity);
    }

    public CartAdapter(List<CartItem> cartItems, OnCartItemActionListener listener) {
        this.cartItems = cartItems;
        this.onCartItemActionListener = listener;
    }

    @NonNull
    @Override
    public CartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_cart, parent, false);
        return new CartViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CartViewHolder holder, int position) {
        CartItem cartItem = cartItems.get(position);

        holder.tvProductName.setText(cartItem.getProductName());
        holder.tvProductPrice.setText(String.format("Giá: %.2f VND", cartItem.getProductPrice()));
        holder.tvQuantity.setText(String.valueOf(cartItem.getQuantity()));
        Glide.with(holder.itemView.getContext()).load(cartItem.getProductImage()).into(holder.imgProduct);

        // Xử lý tăng giảm số lượng
        holder.btnIncrease.setOnClickListener(v -> {
            int newQuantity = cartItem.getQuantity() + 1;
            onCartItemActionListener.onUpdateCartItemQuantity(cartItem, newQuantity);
        });

        holder.btnDecrease.setOnClickListener(v -> {
            int newQuantity = cartItem.getQuantity() - 1;
            if (newQuantity > 0) {
                onCartItemActionListener.onUpdateCartItemQuantity(cartItem, newQuantity);
            }
        });

        // Xử lý xóa sản phẩm khỏi giỏ hàng
        holder.btnDelete.setOnClickListener(v -> onCartItemActionListener.onDeleteCartItem(cartItem));
    }

    @Override
    public int getItemCount() {
        return cartItems.size();
    }

    static class CartViewHolder extends RecyclerView.ViewHolder {
        TextView tvProductName, tvProductPrice, tvQuantity;
        ImageView imgProduct;
        ImageView btnIncrease, btnDecrease, btnDelete;

        public CartViewHolder(@NonNull View itemView) {
            super(itemView);
            tvProductName = itemView.findViewById(R.id.tv_product_name);
            tvProductPrice = itemView.findViewById(R.id.tv_product_price);
            tvQuantity = itemView.findViewById(R.id.tv_quantity);
            imgProduct = itemView.findViewById(R.id.img_product);
            btnIncrease = itemView.findViewById(R.id.btn_increase_quantity);
            btnDecrease = itemView.findViewById(R.id.btn_decrease_quantity);
            btnDelete = itemView.findViewById(R.id.btn_delete);
        }
    }
}
