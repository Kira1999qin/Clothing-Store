package edu.clothes.clothes.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

import edu.clothes.clothes.Model.Product;
import edu.clothes.clothes.R;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ProductViewHolder> {

    private List<Product> productList;
    private OnProductClickListener onProductClickListener;

    public interface OnProductClickListener {
        void onProductClick(Product product);
    }

    public ProductAdapter(List<Product> productList, OnProductClickListener listener) {
        this.productList = productList;
        this.onProductClickListener = listener;
    }

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_product, parent, false);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, int position) {
        Product product = productList.get(position);

        // Gán dữ liệu sản phẩm vào view
        holder.tvName.setText(product.getName());
        holder.tvPrice.setText(String.format("Giá: %.2f", product.getPrice()));
        holder.tvType.setText("Loại: " + product.getType());
        holder.tvGender.setText("Dành cho: " + product.getGender());
        holder.tvBrand.setText("Thương hiệu: " + product.getBrand());

        // Tải ảnh sản phẩm với Glide
        Glide.with(holder.itemView.getContext())
                .load(product.getImageUrl()) // URL của ảnh
                .into(holder.imgProduct);

        // Xử lý sự kiện click
        holder.itemView.setOnClickListener(v -> onProductClickListener.onProductClick(product));
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    static class ProductViewHolder extends RecyclerView.ViewHolder {

        TextView tvName, tvPrice, tvType, tvGender, tvBrand;
        ImageView imgProduct;

        public ProductViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tv_product_name);
            tvPrice = itemView.findViewById(R.id.tv_product_price);
            tvType = itemView.findViewById(R.id.tv_product_type);
            tvGender = itemView.findViewById(R.id.tv_product_gender);
            tvBrand = itemView.findViewById(R.id.tv_product_brand);
            imgProduct = itemView.findViewById(R.id.img_product);
        }
    }

}
