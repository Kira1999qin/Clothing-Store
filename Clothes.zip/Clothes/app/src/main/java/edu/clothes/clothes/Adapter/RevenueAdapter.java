package edu.clothes.clothes.Adapter;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import edu.clothes.clothes.Model.Revenue;
import edu.clothes.clothes.R;

public class RevenueAdapter extends RecyclerView.Adapter<RevenueAdapter.RevenueViewHolder> {

    private List<Revenue> revenueList;

    public RevenueAdapter(List<Revenue> revenueList) {
        this.revenueList = revenueList;
    }

    @NonNull
    @Override
    public RevenueViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_revenue, parent, false);
        return new RevenueViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RevenueViewHolder holder, int position) {
        Revenue revenue = revenueList.get(position);
        holder.tvOrderDate.setText(revenue.getOrderDate());
        holder.tvTotalAmount.setText(String.format("%.2f VND", revenue.getTotalAmount()));
    }

    @Override
    public int getItemCount() {
        return revenueList.size();
    }

    public static class RevenueViewHolder extends RecyclerView.ViewHolder {
        TextView tvOrderDate, tvTotalAmount;

        public RevenueViewHolder(@NonNull View itemView) {
            super(itemView);
            tvOrderDate = itemView.findViewById(R.id.tv_order_date);
            tvTotalAmount = itemView.findViewById(R.id.tv_total_amount);
        }
    }
}

