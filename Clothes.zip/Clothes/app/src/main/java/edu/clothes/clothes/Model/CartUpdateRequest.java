package edu.clothes.clothes.Model;

import com.google.gson.annotations.SerializedName;

public class CartUpdateRequest {

    @SerializedName("cartId")
    private int cartId;

    @SerializedName("quantity")
    private int quantity;

    public CartUpdateRequest(int cartId, int quantity) {
        this.cartId = cartId;
        this.quantity = quantity;
    }

    public int getCartId() {
        return cartId;
    }

    public void setCartId(int cartId) {
        this.cartId = cartId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
