package edu.clothes.clothes.Model;

import com.google.gson.annotations.SerializedName;

public class Product implements java.io.Serializable {
    @SerializedName("id")
    private int id;

    @SerializedName("name")
    private String name;

    @SerializedName("price")
    private double price;

    @SerializedName("type")
    private String type;

    @SerializedName("gender")
    private String gender;

    @SerializedName("brand")
    private String brand;

    @SerializedName("image_url")
    private String imageUrl;

    @SerializedName("quantity")
    private int quantity; // Số lượng sản phẩm

    // Constructor
    public Product(String name, double price, String type, String gender, String brand, String imageUrl, int quantity) {
        this.name = name;
        this.price = price;
        this.type = type;
        this.gender = gender;
        this.brand = brand;
        this.imageUrl = imageUrl;
        this.quantity = quantity;
    }

    public Product(int id, String name, double price, String type, String gender, String brand, String imageUrl, int quantity) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.type = type;
        this.gender = gender;
        this.brand = brand;
        this.imageUrl = imageUrl;
        this.quantity = quantity;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public String getType() {
        return type;
    }

    public String getGender() {
        return gender;
    }

    public String getBrand() {
        return brand;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public int getQuantity() {
        return quantity;
    }
}
