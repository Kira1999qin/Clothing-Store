package edu.clothes.clothes.Model;

import com.google.gson.annotations.SerializedName;

public class Revenue {
    @SerializedName("orderDate")
    private String orderDate;
    @SerializedName("totalAmount")
    private double totalAmount;

    public Revenue(String orderDate, double totalAmount) {
        this.orderDate = orderDate;
        this.totalAmount = totalAmount;
    }

    public String getOrderDate() {
        return orderDate;
    }

    public double getTotalAmount() {
        return totalAmount;
    }
}
