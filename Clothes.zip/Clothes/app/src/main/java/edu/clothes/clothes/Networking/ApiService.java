package edu.clothes.clothes.Networking;

import edu.clothes.clothes.Model.CartItem;
import edu.clothes.clothes.Model.CartRequest;
import edu.clothes.clothes.Model.CartUpdateRequest;
import edu.clothes.clothes.Model.Response;
import edu.clothes.clothes.Model.Product;
import edu.clothes.clothes.Model.Revenue;
import edu.clothes.clothes.Model.User;

import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;

public interface ApiService {

    // Customer APIs
    @POST("customer/register")
    Call<Response<Void>> register(@Body User user); // API Đăng ký

    @POST("customer/login")
    Call<Response<User>> login(@Body User user); // API Đăng nhập

    @GET("products")
    Call<Response<List<Product>>> getProducts(); // API Lấy danh sách sản phẩm

    // Manager APIs
    @GET("manager/users")
    Call<Response<List<User>>> getUsers(); // API Lấy danh sách người dùng

    @POST("manager/users")
    Call<Response<Void>> addUser(@Body User user); // API Thêm người dùng

    @PUT("manager/users/{id}")
    Call<Response<Void>> updateUser(@Path("id") int id, @Body User user); // API Cập nhật người dùng

    @DELETE("manager/users/{id}")
    Call<Response<Void>> deleteUser(@Path("id") int id); // API Xóa người dùng

    // Product Management APIs
    @POST("products")
    Call<Response<Void>> addProduct(@Body Product product); // API Thêm sản phẩm

    @PUT("products/{id}")
    Call<Response<Void>> updateProduct(@Path("id") int id, @Body Product product); // API Cập nhật sản phẩm

    @DELETE("products/{id}")
    Call<Response<Void>> deleteProduct(@Path("id") int id); // API Xóa sản phẩm


    @POST("cart/add")
    Call<Response<Void>> addToCart(@Body CartRequest cartRequest);

    @PUT("cart/update")
    Call<Response<Void>> updateCartQuantity(@Body CartUpdateRequest cartUpdateRequest);

    @GET("cart/{userId}")
    Call<Response<List<CartItem>>> getCartByUserId(@Path("userId") int userId);

    @DELETE("cart/{cartId}")
    Call<Response<Void>> deleteCartItem(@Path("cartId") int cartId);

    @POST("cart/checkout")
    Call<Response<Void>> checkout(@Body Map<String, String> user);

    @GET("cart/order/revenue")
    Call<Response<List<Revenue>>> getRevenue();

}


