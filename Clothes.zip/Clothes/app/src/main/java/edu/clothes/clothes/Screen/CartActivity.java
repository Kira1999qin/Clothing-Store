package edu.clothes.clothes.Screen;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import edu.clothes.clothes.Adapter.CartAdapter;
import edu.clothes.clothes.Model.CartItem;
import edu.clothes.clothes.Model.CartUpdateRequest;
import edu.clothes.clothes.Model.User;
import edu.clothes.clothes.Networking.ApiClient;
import edu.clothes.clothes.Networking.ApiService;
import edu.clothes.clothes.R;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CartActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private CartAdapter cartAdapter;
    private ApiService apiService;
    private List<CartItem> cartItems;
    private TextView tvTotalPrice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        recyclerView = findViewById(R.id.recycler_view_cart);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        tvTotalPrice = findViewById(R.id.tv_total_price);

        apiService = ApiClient.getClient().create(ApiService.class);

        fetchCartItems(LoginActivity._muser.getId()); // Ví dụ: userId = 1

        findViewById(R.id.btn_checkout).setOnClickListener(v -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Xác nhận thanh toán");
            builder.setMessage("Bạn có chắc chắn muốn thanh toán?");
            builder.setPositiveButton("Có", (dialog, which) -> {
                checkout(LoginActivity._muser.getId()); // Ví dụ: userId = 1
            });
            builder.setNegativeButton("Không", (dialog, which) -> dialog.dismiss());
            builder.show();
        });
    }

    private void fetchCartItems(int userId) {
        apiService.getCartByUserId(userId).enqueue(new Callback<edu.clothes.clothes.Model.Response<List<CartItem>>>() {
            @Override
            public void onResponse(Call<edu.clothes.clothes.Model.Response<List<CartItem>>> call, Response<edu.clothes.clothes.Model.Response<List<CartItem>>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    cartItems = response.body().getData();
                    setupRecyclerView();
                    updateTotalPrice(); // Cập nhật tổng tiền
                } else {
                    Toast.makeText(CartActivity.this, "Không thể tải giỏ hàng!", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<edu.clothes.clothes.Model.Response<List<CartItem>>> call, Throwable t) {
                Toast.makeText(CartActivity.this, "Lỗi kết nối!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setupRecyclerView() {
        cartAdapter = new CartAdapter(cartItems, new CartAdapter.OnCartItemActionListener() {
            @Override
            public void onDeleteCartItem(CartItem cartItem) {
                deleteCartItem(cartItem.getCartId());
            }

            @Override
            public void onUpdateCartItemQuantity(CartItem cartItem, int newQuantity) {
                updateCartItemQuantity(cartItem.getCartId(), newQuantity);
            }
        });
        recyclerView.setAdapter(cartAdapter);
    }

    private void updateTotalPrice() {
        double totalPrice = 0;
        for (CartItem item : cartItems) {
            totalPrice += item.getTotal();
        }
        tvTotalPrice.setText(String.format("Tổng tiền: %.2f VND", totalPrice));
    }

    private void deleteCartItem(int cartId) {
        apiService.deleteCartItem(cartId).enqueue(new Callback<edu.clothes.clothes.Model.Response<Void>>() {
            @Override
            public void onResponse(Call<edu.clothes.clothes.Model.Response<Void>> call, Response<edu.clothes.clothes.Model.Response<Void>> response) {
                if (response.isSuccessful() && response.body().isSuccess()) {
                    fetchCartItems(1); // Cập nhật giỏ hàng
                    Toast.makeText(CartActivity.this, "Sản phẩm đã được xóa!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(CartActivity.this, "Không thể xóa sản phẩm!", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<edu.clothes.clothes.Model.Response<Void>> call, Throwable t) {
                Toast.makeText(CartActivity.this, "Lỗi kết nối!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateCartItemQuantity(int cartId, int newQuantity) {
        CartUpdateRequest request = new CartUpdateRequest(cartId, newQuantity);
        apiService.updateCartQuantity(request).enqueue(new Callback<edu.clothes.clothes.Model.Response<Void>>() {
            @Override
            public void onResponse(Call<edu.clothes.clothes.Model.Response<Void>> call, Response<edu.clothes.clothes.Model.Response<Void>> response) {
                if (response.isSuccessful() && response.body().isSuccess()) {
                    fetchCartItems(1); // Cập nhật giỏ hàng
                    Toast.makeText(CartActivity.this, "Cập nhật số lượng thành công!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(CartActivity.this, "Không thể cập nhật số lượng!", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<edu.clothes.clothes.Model.Response<Void>> call, Throwable t) {
                Toast.makeText(CartActivity.this, "Lỗi kết nối!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void checkout(int userId) {
        Map<String, String> user = new HashMap<>();
        user.put("userId", String.valueOf(userId));
        apiService.checkout(user).enqueue(new Callback<edu.clothes.clothes.Model.Response<Void>>() {
            @Override
            public void onResponse(Call<edu.clothes.clothes.Model.Response<Void>> call, Response<edu.clothes.clothes.Model.Response<Void>> response) {
                if (response.isSuccessful() && response.body().isSuccess()) {
                    fetchCartItems(userId); // Làm mới giỏ hàng
                    tvTotalPrice.setText("Tổng tiền: 0 VND");
                    Toast.makeText(CartActivity.this, "Thanh toán thành công!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(CartActivity.this, "Không thể thanh toán!", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<edu.clothes.clothes.Model.Response<Void>> call, Throwable t) {
                Toast.makeText(CartActivity.this, "Lỗi kết nối!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
