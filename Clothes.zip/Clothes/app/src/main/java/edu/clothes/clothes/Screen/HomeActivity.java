package edu.clothes.clothes.Screen;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

import edu.clothes.clothes.Adapter.ProductAdapter;
import edu.clothes.clothes.Adapter.ProductAdapter2;
import edu.clothes.clothes.Model.Product;
import edu.clothes.clothes.Networking.ApiClient;
import edu.clothes.clothes.Networking.ApiService;
import edu.clothes.clothes.R;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ProductAdapter2 productAdapter;
    private List<Product> productList = new ArrayList<>();
    private ApiService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        recyclerView = findViewById(R.id.recycler_view_products);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        SearchView searchView = findViewById(R.id.search_view);
        FloatingActionButton fabCart = findViewById(R.id.fab_cart);

        apiService = ApiClient.getClient().create(ApiService.class);

        // Navigate to Cart
        fabCart.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, CartActivity.class);
            startActivity(intent);
        });

        // Search functionality
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                filterProducts(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterProducts(newText);
                return false;
            }
        });
    }

    private void fetchProducts() {
        apiService.getProducts().enqueue(new Callback<edu.clothes.clothes.Model.Response<List<Product>>>() {
            @Override
            public void onResponse(Call<edu.clothes.clothes.Model.Response<List<Product>>> call, Response<edu.clothes.clothes.Model.Response<List<Product>>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    productList = response.body().getData();
                    setupRecyclerView();
                } else {
                    Toast.makeText(HomeActivity.this, "Không thể tải danh sách sản phẩm!", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<edu.clothes.clothes.Model.Response<List<Product>>> call, Throwable t) {
                Toast.makeText(HomeActivity.this, "Lỗi khi tải sản phẩm!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setupRecyclerView() {
        productAdapter = new ProductAdapter2(productList, product -> {
            Intent intent = new Intent(HomeActivity.this, ProductDetailActivity.class);
            intent.putExtra("product", product);
            startActivity(intent);
        });
        recyclerView.setAdapter(productAdapter);
    }


    private void filterProducts(String query) {
        if (query == null || query.trim().isEmpty()) {
            productAdapter.updateList(productList); // Hiển thị danh sách gốc nếu không nhập
            return;
        }

        List<Product> filteredList = new ArrayList<>();
        for (Product product : productList) {
            if (product.getName().toLowerCase().contains(query.toLowerCase())) {
                filteredList.add(product);
            }
        }

        productAdapter.updateList(filteredList);

        if (filteredList.isEmpty()) {
            Toast.makeText(this, "Không tìm thấy sản phẩm nào!", Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        fetchProducts();
    }
}
