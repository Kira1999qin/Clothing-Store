package edu.clothes.clothes.Screen;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


import edu.clothes.clothes.Model.Response;
import edu.clothes.clothes.Model.User;
import edu.clothes.clothes.Networking.ApiClient;
import edu.clothes.clothes.Networking.ApiService;
import edu.clothes.clothes.databinding.ActivityLoginBinding;
import retrofit2.Call;
import retrofit2.Callback;

public class LoginActivity extends AppCompatActivity {

    private ActivityLoginBinding binding;
    public static User _muser = new User();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Sử dụng ViewBinding
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Sự kiện khi nhấn nút "Đăng nhập"
        binding.btnDangnhap.setOnClickListener(v -> loginUser());

        // Sự kiện khi nhấn "Đăng ký"
        binding.btnDangky.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent);
        });

        // Sự kiện khi nhấn "Quên mật khẩu"
        binding.tvForgotPassword.setOnClickListener(v ->
                Toast.makeText(this, "Chức năng quên mật khẩu đang phát triển", Toast.LENGTH_SHORT).show()
        );
    }

    private void loginUser() {
        String email = binding.edtEmailUser.getText().toString().trim();
        String password = binding.edtMatkhauUser.getText().toString().trim();

        // Kiểm tra các trường
        if (TextUtils.isEmpty(email)) {
            Toast.makeText(this, "Vui lòng nhập email!", Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Vui lòng nhập mật khẩu!", Toast.LENGTH_SHORT).show();
            return;
        }

        // Tạo đối tượng User để gửi đến API
        User user = new User(email, password, null);

        // Gọi API đăng nhập
        ApiService apiService = ApiClient.getClient().create(ApiService.class);

        apiService.login(user).enqueue(new Callback<Response<User>>() {
            @Override
            public void onResponse(Call<Response<User>> call, retrofit2.Response<Response<User>> response) {
                if(response.body().isSuccess()) {
                    User user = response.body().getData();
                    _muser = user;
                    Intent intent;
                    if(user.getRole().equals("Customer")) {
                        intent = new Intent(LoginActivity.this, HomeActivity.class);
                    } else {
                        intent = new Intent(LoginActivity.this, ManagerActivity.class);
                    }
                    startActivity(intent);
                    Log.d("loginAPI", "onResponse: " + user.getUsername());
                } else {
                    Toast.makeText(LoginActivity.this, "Đăng nhập thất bại!", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Response<User>> call, Throwable t) {

            }
        });
    }
}
