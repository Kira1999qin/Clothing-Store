package edu.clothes.clothes.Screen;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

import edu.clothes.clothes.Adapter.ProductAdapter;
import edu.clothes.clothes.Model.Product;
import edu.clothes.clothes.Networking.ApiClient;
import edu.clothes.clothes.Networking.ApiService;
import edu.clothes.clothes.R;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ManagerProductsActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ProductAdapter productAdapter;
    private List<Product> productList;
    private ApiService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manager_products);

        recyclerView = findViewById(R.id.recycler_view_products);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        apiService = ApiClient.getClient().create(ApiService.class);

        fetchProducts();

        FloatingActionButton fabAddProduct = findViewById(R.id.fab_add_product);
        fabAddProduct.setOnClickListener(v -> openProductDialog(null)); // null for new product
    }

    private void fetchProducts() {
        apiService.getProducts().enqueue(new Callback<edu.clothes.clothes.Model.Response<List<Product>>>() {
            @Override
            public void onResponse(Call<edu.clothes.clothes.Model.Response<List<Product>>> call, Response<edu.clothes.clothes.Model.Response<List<Product>>> response) {
                if (response.isSuccessful()) {
                    productList = response.body().getData();
                    setupRecyclerView();
                    productAdapter.notifyDataSetChanged();
                }else{
                    Toast.makeText(ManagerProductsActivity.this, "Không thể lấy danh sách sản phẩm!", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<edu.clothes.clothes.Model.Response<List<Product>>> call, Throwable t) {
                Toast.makeText(ManagerProductsActivity.this, "Không thể lấy danh sách sản phẩm!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setupRecyclerView() {
        productAdapter = new ProductAdapter(productList, product -> openProductDialog(product));
        recyclerView.setAdapter(productAdapter);
    }

    private void openProductDialog(Product product) {
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_add_edit_product);

        EditText edtName = dialog.findViewById(R.id.edt_product_name);
        EditText edtPrice = dialog.findViewById(R.id.edt_product_price);
        Spinner spinnerType = dialog.findViewById(R.id.spinner_product_type);
        Spinner spinnerGender = dialog.findViewById(R.id.spinner_product_gender);
        EditText edtBrand = dialog.findViewById(R.id.edt_product_brand);
        EditText edtImageUrl = dialog.findViewById(R.id.edt_product_image_url);
        EditText edtQuantity = dialog.findViewById(R.id.edt_product_quantity);
        Button btnSave = dialog.findViewById(R.id.btn_save_product);
        Button btnCancel = dialog.findViewById(R.id.btn_cancel_product);
        Button btnDelete = dialog.findViewById(R.id.btn_delete_product);

        // Set up spinner for product types
        ArrayAdapter<String> typeAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, new String[]{"Áo", "Quần", "Giày"});
        typeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerType.setAdapter(typeAdapter);

        // Set up spinner for genders
        ArrayAdapter<String> genderAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, new String[]{"Nam", "Nữ"});
        genderAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerGender.setAdapter(genderAdapter);

        if (product != null) {
            edtName.setText(product.getName());
            edtPrice.setText(String.valueOf(product.getPrice()));
            edtBrand.setText(product.getBrand());
            edtImageUrl.setText(product.getImageUrl());
            edtQuantity.setText(String.valueOf(product.getQuantity()));

            // Set the spinners' selected items
            int typePosition = typeAdapter.getPosition(product.getType());
            spinnerType.setSelection(typePosition);

            int genderPosition = genderAdapter.getPosition(product.getGender());
            spinnerGender.setSelection(genderPosition);
        } else {
            btnDelete.setVisibility(View.GONE); // Ẩn nút "Xóa" nếu là sản phẩm mới
        }

        btnSave.setOnClickListener(v -> {
            String name = edtName.getText().toString();
            double price = Double.parseDouble(edtPrice.getText().toString());
            String type = spinnerType.getSelectedItem().toString();
            String gender = spinnerGender.getSelectedItem().toString();
            String brand = edtBrand.getText().toString();
            String imageUrl = edtImageUrl.getText().toString();
            int quantity = Integer.parseInt(edtQuantity.getText().toString());

            if (name.isEmpty() || brand.isEmpty() || imageUrl.isEmpty() || quantity < 0) {
                Toast.makeText(this, "Vui lòng nhập đầy đủ thông tin!", Toast.LENGTH_SHORT).show();
                return;
            }

            if (product == null) {
                addProduct(name, price, type, gender, brand, imageUrl, quantity);
            } else {
                updateProduct(product.getId(), name, price, type, gender, brand, imageUrl, quantity);
            }
            dialog.dismiss();
        });

        btnCancel.setOnClickListener(v -> dialog.dismiss());

        btnDelete.setOnClickListener(v -> {
            if (product != null) {
                deleteProduct(product.getId());
                dialog.dismiss();
            }
        });

        dialog.show();
    }


    private void deleteProduct(int id) {
        apiService.deleteProduct(id).enqueue(new Callback<edu.clothes.clothes.Model.Response<Void>>() {
            @Override
            public void onResponse(Call<edu.clothes.clothes.Model.Response<Void>> call, Response<edu.clothes.clothes.Model.Response<Void>> response) {
                if (response.isSuccessful()) {
                    fetchProducts();
                    Toast.makeText(ManagerProductsActivity.this, "Sản phẩm đã được xóa!", Toast.LENGTH_SHORT).show();
                } else {
                    showError("Không thể xóa sản phẩm!");
                }
            }

            @Override
            public void onFailure(Call<edu.clothes.clothes.Model.Response<Void>> call, Throwable t) {
                showError("Không thể xóa sản phẩm!");
            }
        });
    }


    private void addProduct(String name, double price, String type, String gender, String brand, String imageUrl, int quantity) {
        Product product = new Product(name, price, type, gender, brand, imageUrl, quantity);
        apiService.addProduct(product).enqueue(new Callback<edu.clothes.clothes.Model.Response<Void>>() {
            @Override
            public void onResponse(Call<edu.clothes.clothes.Model.Response<Void>> call, Response<edu.clothes.clothes.Model.Response<Void>> response) {
                if (response.isSuccessful()) {
                    fetchProducts();
                    Toast.makeText(ManagerProductsActivity.this, "Sản phẩm được thêm!", Toast.LENGTH_SHORT).show();
                } else {
                    showError("Không thể thêm sản phẩm!");
                }
            }

            @Override
            public void onFailure(Call<edu.clothes.clothes.Model.Response<Void>> call, Throwable t) {
                showError("Không thể thêm sản phẩm!");
            }
        });
    }


    private void updateProduct(int id, String name, double price, String type, String gender, String brand, String imageUrl, int quantity) {
        Product product = new Product(id, name, price, type, gender, brand, imageUrl, quantity);
        apiService.updateProduct(id, product).enqueue(new Callback<edu.clothes.clothes.Model.Response<Void>>() {
            @Override
            public void onResponse(Call<edu.clothes.clothes.Model.Response<Void>> call, Response<edu.clothes.clothes.Model.Response<Void>> response) {
                if (response.isSuccessful()) {
                    fetchProducts();
                    Toast.makeText(ManagerProductsActivity.this, "Sản phẩm được cập nhật!", Toast.LENGTH_SHORT).show();
                } else {
                    showError("Không thể cập nhật sản phẩm!");
                }
            }

            @Override
            public void onFailure(Call<edu.clothes.clothes.Model.Response<Void>> call, Throwable t) {
                showError("Không thể cập nhật sản phẩm!");
            }
        });
    }


    private void showError(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
