package edu.clothes.clothes.Screen;

import static edu.clothes.clothes.Screen.LoginActivity._muser;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

import edu.clothes.clothes.Model.CartRequest;
import edu.clothes.clothes.Model.Product;
import edu.clothes.clothes.Networking.ApiClient;
import edu.clothes.clothes.Networking.ApiService;
import edu.clothes.clothes.R;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProductDetailActivity extends AppCompatActivity {

    private ApiService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);

        ImageView imgProduct = findViewById(R.id.img_product);
        TextView tvProductName = findViewById(R.id.tv_product_name);
        TextView tvProductPrice = findViewById(R.id.tv_product_price);
        TextView tvProductType = findViewById(R.id.tv_product_type);
        TextView tvProductGender = findViewById(R.id.tv_product_gender);
        TextView tvProductBrand = findViewById(R.id.tv_product_brand);
        TextView tvProductQuantity = findViewById(R.id.tv_product_quantity);
        Button btnAddToCart = findViewById(R.id.btn_add_to_cart);
        apiService = ApiClient.getClient().create(ApiService.class);
        Product product = (Product) getIntent().getSerializableExtra("product");

        if (product != null) {
            tvProductName.setText(product.getName());
            tvProductPrice.setText(String.format("Giá: %.2f VND", product.getPrice()));
            tvProductType.setText("Loại sản phẩm: " + product.getType());
            tvProductGender.setText("Giới tính: " + product.getGender());
            tvProductBrand.setText("Thương hiệu: " + product.getBrand());
            tvProductQuantity.setText("Số lượng: " + product.getQuantity());
            Glide.with(this).load(product.getImageUrl()).into(imgProduct);

            btnAddToCart.setOnClickListener(v -> {
                if (product.getQuantity() > 0) {
                    addToCart(_muser.getId(), product.getId(), 1);
                } else {
                    Toast.makeText(this, "Sản phẩm này đã hết hàng!", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }


    private void addToCart(int userId, int productId, int quantity) {
        CartRequest cartRequest = new CartRequest(userId, productId, quantity);
        apiService.addToCart(cartRequest).enqueue(new Callback<edu.clothes.clothes.Model.Response<Void>>() {
            @Override
            public void onResponse(Call<edu.clothes.clothes.Model.Response<Void>> call, Response<edu.clothes.clothes.Model.Response<Void>> response) {
                if (response.isSuccessful() && response.body().isSuccess()) {
                    Toast.makeText(ProductDetailActivity.this, "Đã thêm vào giỏ hàng!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(ProductDetailActivity.this, "Không thể thêm vào giỏ hàng!", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<edu.clothes.clothes.Model.Response<Void>> call, Throwable t) {
                Toast.makeText(ProductDetailActivity.this, "Lỗi kết nối!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
