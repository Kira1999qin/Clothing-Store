package edu.clothes.clothes.Screen;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


import edu.clothes.clothes.Model.Response;
import edu.clothes.clothes.Model.User;
import edu.clothes.clothes.Networking.ApiClient;
import edu.clothes.clothes.Networking.ApiService;
import edu.clothes.clothes.databinding.ActivityRegisterBinding;
import retrofit2.Call;
import retrofit2.Callback;

public class RegisterActivity extends AppCompatActivity {

    private ActivityRegisterBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Sử dụng ViewBinding
        binding = ActivityRegisterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Đăng ký sự kiện cho nút "Đăng ký"
        binding.btnSignUpDangky.setOnClickListener(v -> registerUser());
    }

    private void registerUser() {
        String email = binding.edtSignUpEmail.getText().toString().trim();
        String password = binding.edtSignUpPassword.getText().toString().trim();
        String confirmPassword = binding.edtSignUpConfirm.getText().toString().trim();

        // Kiểm tra các trường
        if (TextUtils.isEmpty(email)) {
            Toast.makeText(this, "Vui lòng nhập email!", Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Vui lòng nhập mật khẩu!", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!password.equals(confirmPassword)) {
            Toast.makeText(this, "Mật khẩu nhập lại không khớp!", Toast.LENGTH_SHORT).show();
            return;
        }

        // Tạo đối tượng User
        User user = new User(email, password, "Customer");

        // Gọi API đăng ký
        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        apiService.register(user).enqueue(new Callback<Response<Void>>() {
            @Override
            public void onResponse(Call<Response<Void>> call, retrofit2.Response<Response<Void>> response) {
                if(response.body().isSuccess()) {
                    Toast.makeText(RegisterActivity.this, "Đăng ký thành công!", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(RegisterActivity.this, "Đăng ký thất bại! " + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Response<Void>> call, Throwable t) {

            }
        });
    }
}
