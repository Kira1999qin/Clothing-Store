package edu.clothes.clothes.Screen;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import edu.clothes.clothes.Adapter.RevenueAdapter;
import edu.clothes.clothes.Model.Response;
import edu.clothes.clothes.Model.Revenue;
import edu.clothes.clothes.Networking.ApiClient;
import edu.clothes.clothes.Networking.ApiService;
import edu.clothes.clothes.R;
import retrofit2.Call;
import retrofit2.Callback;

public class RevenueStatistics extends AppCompatActivity {

    private RecyclerView recyclerView;
    private RevenueAdapter revenueAdapter;
    private TextView tvTotalSummary;
    private ApiService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_revenue_statistics);

        recyclerView = findViewById(R.id.recycler_view_revenue);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        tvTotalSummary = findViewById(R.id.tv_total_summary);

        apiService = ApiClient.getClient().create(ApiService.class);

        fetchRevenueStatistics();
    }

    private void fetchRevenueStatistics() {
        apiService.getRevenue().enqueue(new Callback<Response<List<Revenue>>>() {
            @Override
            public void onResponse(Call<Response<List<Revenue>>> call, retrofit2.Response<Response<List<Revenue>>> response) {
                Log.d("RevenueStatisticsAPI", "onResponse: " + response.body().getData().get(0).getTotalAmount());
                if (response.isSuccessful() && response.body() != null) {
                    List<Revenue> revenueList = response.body().getData();
                    revenueAdapter = new RevenueAdapter(revenueList);
                    recyclerView.setAdapter(revenueAdapter);
                    double total = 0;
                    for (Revenue revenue : revenueList) {
                        total += revenue.getTotalAmount();
                    }
                    tvTotalSummary.setText(String.format("Tổng thu: %.2f VND", total));
                } else {
                    Toast.makeText(RevenueStatistics.this, "Không thể tải dữ liệu!", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Response<List<Revenue>>> call, Throwable t) {
                Log.e("RevenueStatisticsAPI", "onFailure: " + t.getMessage());
            }
        });
    }
}
