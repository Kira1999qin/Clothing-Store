package edu.clothes.clothes.Screen;

import android.app.Dialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

import edu.clothes.clothes.Adapter.UserAdapter;
import edu.clothes.clothes.Model.User;
import edu.clothes.clothes.Networking.ApiClient;
import edu.clothes.clothes.Networking.ApiService;
import edu.clothes.clothes.R;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UserManagementActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private UserAdapter userAdapter;
    private List<User> userList;
    private ApiService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_management);

        recyclerView = findViewById(R.id.recycler_view_users);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        apiService = ApiClient.getClient().create(ApiService.class);

        fetchUsers();

        FloatingActionButton fabAddUser = findViewById(R.id.fab_add_user);
        fabAddUser.setOnClickListener(v -> openUserDialog(null)); // null for adding new user
    }

    private void fetchUsers() {
        apiService.getUsers().enqueue(new Callback<edu.clothes.clothes.Model.Response<List<User>>>() {
            @Override
            public void onResponse(Call<edu.clothes.clothes.Model.Response<List<User>>> call, Response<edu.clothes.clothes.Model.Response<List<User>>> response) {
                if (response.isSuccessful()) {
                    userList = response.body().getData();
                    setupRecyclerView();
                    userAdapter.notifyDataSetChanged();
                } else {
                    showError("Không thể tải danh sách người dùng!");
                }
                findViewById(R.id.progress_bar).setVisibility(View.GONE);
            }

            @Override
            public void onFailure(Call<edu.clothes.clothes.Model.Response<List<User>>> call, Throwable t) {
                showError("Không thể tải danh sách người dùng!");
                Log.e("UserManagementActivity", "onFailure: " + t.getMessage());
                findViewById(R.id.progress_bar).setVisibility(View.GONE);
            }
        });
    }

    private void setupRecyclerView() {
        userAdapter = new UserAdapter(userList, user -> openUserDialog(user));
        recyclerView.setAdapter(userAdapter);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
    }

    private void openUserDialog(User user) {
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_add_users);

        // View bindings
        EditText edtEmail = dialog.findViewById(R.id.edt_email);
        EditText edtPassword = dialog.findViewById(R.id.edt_password);
        Spinner spinnerRole = dialog.findViewById(R.id.spinner_role);
        Button btnSave = dialog.findViewById(R.id.btn_save_user);
        Button btnDelete = dialog.findViewById(R.id.btn_delete_user);
        Button btnCancel = dialog.findViewById(R.id.btn_cancel_user);

        // Populate spinner
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.roles_array,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerRole.setAdapter(adapter);

        if (user != null) {
            // Edit user
            edtEmail.setText(user.getUsername());
            edtPassword.setVisibility(View.GONE); // Hide password for editing
            int spinnerPosition = adapter.getPosition(user.getRole());
            spinnerRole.setSelection(spinnerPosition);

            btnDelete.setVisibility(View.VISIBLE); // Show delete button
        }

        btnSave.setOnClickListener(v -> {
            String email = edtEmail.getText().toString();
            String password = edtPassword.getText().toString();
            String role = spinnerRole.getSelectedItem().toString();



            if (user == null) {
                if (email.isEmpty() || password.isEmpty() || role.isEmpty()) {
                    Toast.makeText(UserManagementActivity.this, "Vui lòng nhập đầy đủ thông tin!", Toast.LENGTH_SHORT).show();
                    return;
                }
                addUser(email, password, role);
            } else {
                if (email.isEmpty() || role.isEmpty()) {
                    Toast.makeText(UserManagementActivity.this, "Vui lòng nhập đầy đủ thông tin!", Toast.LENGTH_SHORT).show();
                    return;
                }
                updateUser(user.getId(), email, role, user.getPassword());
            }
            dialog.dismiss();
        });

        btnDelete.setOnClickListener(v -> {
            if (user != null) {
                deleteUser(user.getId());
                dialog.dismiss();
            }
        });

        btnCancel.setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    private void deleteUser(int id) {
        apiService.deleteUser(id).enqueue(new Callback<edu.clothes.clothes.Model.Response<Void>>() {
            @Override
            public void onResponse(Call<edu.clothes.clothes.Model.Response<Void>> call, Response<edu.clothes.clothes.Model.Response<Void>> response) {
                if (response.isSuccessful()) {
                    fetchUsers();
                    Toast.makeText(UserManagementActivity.this, "Người dùng đã bị xóa!", Toast.LENGTH_SHORT).show();
                } else {
                    showError("Không thể xóa người dùng!");
                }
            }

            @Override
            public void onFailure(Call<edu.clothes.clothes.Model.Response<Void>> call, Throwable t) {
                showError("Không thể xóa người dùng!");
            }
        });
    }


    private void addUser(String email, String password, String role) {
        User newUser = new User(email, password, role);
        apiService.addUser(newUser).enqueue(new Callback<edu.clothes.clothes.Model.Response<Void>>() {
            @Override
            public void onResponse(Call<edu.clothes.clothes.Model.Response<Void>> call, Response<edu.clothes.clothes.Model.Response<Void>> response) {
                if (response.isSuccessful()) {
                    fetchUsers();
                    Toast.makeText(UserManagementActivity.this, "Người dùng được thêm!", Toast.LENGTH_SHORT).show();
                }else{
                    showError("Không thể thêm người dùng!");
                }

            }

            @Override
            public void onFailure(Call<edu.clothes.clothes.Model.Response<Void>> call, Throwable t) {
                showError("Không thể thêm người dùng!");
            }
        });
    }

    private void updateUser(int id, String email, String role, String password) {
        apiService.updateUser(id, new User(email, password, role)).enqueue(new Callback<edu.clothes.clothes.Model.Response<Void>>() {
            @Override
            public void onResponse(Call<edu.clothes.clothes.Model.Response<Void>> call, Response<edu.clothes.clothes.Model.Response<Void>> response) {
                if (response.isSuccessful()) {
                    fetchUsers();
                    Toast.makeText(UserManagementActivity.this, "Người dùng được cập nhật!", Toast.LENGTH_SHORT).show();
                }else{
                    showError("Không thể cập nhật người dùng!");
                }
            }

            @Override
            public void onFailure(Call<edu.clothes.clothes.Model.Response<Void>> call, Throwable t) {
                showError("Không thể cập nhật người dùng!");
            }
        });
    }

    private void showError(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
