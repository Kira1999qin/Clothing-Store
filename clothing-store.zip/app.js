const express = require('express');
const bodyParser = require('body-parser');
const db = require('./models/db');

const app = express();
const port = 2409;

// Middleware
app.use(bodyParser.json());

// Routes
const managerRoutes = require('./routes/manager');
const customerRoutes = require('./routes/customer');
const productRoutes = require('./routes/productRoutes');
const cartRouter = require('./routes/cartRouter');

app.use('/manager', managerRoutes);
app.use('/customer', customerRoutes);
app.use('/products', productRoutes);
app.use('/cart', cartRouter);
// Khởi tạo database và server
async function startServer() {
    try {
        await db.initialize(); // Kết nối Oracle Database
        app.listen(port, () => {
            console.log(`Server is running at http://localhost:${port}`);
        });
    } catch (err) {
        console.error('Failed to start server:', err);
    }
}

startServer();
