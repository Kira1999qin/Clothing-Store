const cartModel = require('../models/cartModel');

// Thêm sản phẩm vào giỏ hàng
exports.addToCart = async (req, res) => {
    const { userId, productId, quantity } = req.body;
    try {
        await cartModel.addToCart(userId, productId, quantity);
        res.json({ success: true, message: 'Sản phẩm đã được thêm vào giỏ hàng!' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Không thể thêm vào giỏ hàng!', error: error.message });
    }
};

// Cập nhật số lượng sản phẩm trong giỏ hàng
exports.updateCartQuantity = async (req, res) => {
    const { cartId, quantity } = req.body;
    try {
        await cartModel.updateCartQuantity(cartId, quantity);
        res.json({ success: true, message: 'Cập nhật số lượng sản phẩm thành công!' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Không thể cập nhật số lượng sản phẩm!', error: error.message });
    }
};

// Lấy danh sách sản phẩm trong giỏ hàng theo userId
exports.getCartByUserId = async (req, res) => {
    const { userId } = req.params;
    try {
        const cartItems = await cartModel.getCartByUserId(userId);
        res.json({ success: true, message: 'Lấy danh sách giỏ hàng thành công!', data: cartItems });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Không thể tải giỏ hàng!', error: error.message });
    }
};

// Xóa sản phẩm khỏi giỏ hàng
exports.deleteCartItem = async (req, res) => {
    const { cartId } = req.params;
    try {
        await cartModel.deleteCartItem(cartId);
        res.json({ success: true, message: 'Sản phẩm đã được xóa khỏi giỏ hàng!' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Không thể xóa sản phẩm khỏi giỏ hàng!', error: error.message });
    }
};

// Thanh toán
exports.checkout = async (req, res) => {
    const { userId } = req.body;
    try {
        const result = await cartModel.checkout(userId);
        res.json({ success: true, message: 'Thanh toán thành công!', data: result });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Thanh toán thất bại!', error: error.message });
    }
};


exports.getRevenueStatistics = async (req, res) => {
    try {
        const revenueData = await cartModel.getRevenue();
        console.log(revenueData + ">>>>>>>>");
        res.json({
            success: true,
            message: 'Thống kê doanh thu thành công!',
            data: revenueData,
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            success: false,
            message: 'Thống kê doanh thu thất bại!',
            error: error.message,
        });
    }
};