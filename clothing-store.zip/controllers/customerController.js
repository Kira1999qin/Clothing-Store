const customerModel = require('../models/customerModel');

// Chuẩn hóa response trả về
const createResponse = (success, message, data = null, error = null) => {
    return { success, message, data, error };
};

// Đăng ký người dùng
exports.register = async (req, res) => {
    const { username, password } = req.body;
    try {
        // Kiểm tra email đã tồn tại
        const emailExists = await customerModel.isEmailExists(username);
        if (emailExists) {
            return res.status(400).json({
                success: false,
                message: 'Email đã được sử dụng'
            });
        }

        // Thực hiện đăng ký
        await customerModel.register(username, password);
        res.json({
            success: true,
            message: 'Đăng ký thành công'
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            success: false,
            message: 'Đăng ký thất bại',
            error: error.message
        });
    }
};


const formatCustomer = (data) => {
    if (!data) return null;
    return {
        id: data[0],
        username: data[1],
        password: data[2], // Bạn có thể không gửi mật khẩu về client vì lý do bảo mật
        name: data[3],
        role: data[4]
    };
};

// Đăng nhập người dùng
exports.login = async (req, res) => {
    const { username, password } = req.body;
    try {
        const customerData = await customerModel.login(username, password);
        if (customerData) {
            const formattedCustomer = formatCustomer(customerData);
            console.log(formattedCustomer);
            res.json({
                success: true,
                message: 'Login successful',
                data: formattedCustomer
            });
        } else {
            res.status(401).json({
                success: false,
                message: 'Invalid credentials'
            });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({
            success: false,
            message: 'Login failed',
            error: error.message
        });
    }
};


// Lấy danh sách sản phẩm
exports.getProducts = async (req, res) => {
    try {
        const products = await customerModel.getProducts();
        res.json(createResponse(true, 'Products fetched successfully', { products }));
    } catch (error) {
        console.error(error);
        res.status(500).json(createResponse(false, 'Failed to fetch products', null, error.message));
    }
};

// Thêm sản phẩm vào giỏ hàng
exports.addToCart = async (req, res) => {
    const { userId, productId, quantity } = req.body;
    try {
        await customerModel.addToCart(userId, productId, quantity);
        res.json(createResponse(true, 'Product added to cart'));
    } catch (error) {
        console.error(error);
        res.status(500).json(createResponse(false, 'Failed to add product to cart', null, error.message));
    }
};

// Thanh toán giỏ hàng
exports.checkout = async (req, res) => {
    const { userId } = req.body;
    try {
        const order = await customerModel.checkout(userId);
        res.json(createResponse(true, 'Checkout successful', { order }));
    } catch (error) {
        console.error(error);
        res.status(500).json(createResponse(false, 'Checkout failed', null, error.message));
    }
};
