const managerModel = require('../models/managerModel');
const createResponse = (success, message, data = null, error = null) => {
    return { success, message, data, error };
};

const formatUser = (user) => {
    return {
        id: user[0],
        username: user[1],
        role: user[2],
    };
};


// Lấy danh sách người dùng
exports.getUsers = async (req, res) => {
    try {
        const users = await managerModel.getUsers();
        console.log(users);
        // Format users
        const formattedUsers = users.map(formatUser);

        res.json(createResponse(true, 'Users fetched successfully', users.map(formatUser)));
    } catch (error) {
        console.error(error);
        res.status(500).json(createResponse(false, 'Failed to fetch users', null, error.message));
    }
};


// Thêm người dùng
exports.addUser = async (req, res) => {
    const { username, password, role } = req.body;
    try {
        await managerModel.addUser(username, password, role);
        res.json(createResponse(true, 'User added successfully'));
    } catch (error) {
        console.error(error);
        res.status(500).json(createResponse(false, 'Failed to add user', null, error.message));
    }
};

// Xóa người dùng
exports.deleteUser = async (req, res) => {
    const { id } = req.params;
    try {
        await managerModel.deleteUser(id);
        res.json(createResponse(true, 'User deleted successfully'));
    } catch (error) {
        console.error(error);
        res.status(500).json(createResponse(false, 'Failed to delete user', null, error.message));
    }
};

// Cập nhật người dùng
exports.updateUser = async (req, res) => {
    const { id } = req.params;
    const { username, role } = req.body;
    try {
        await managerModel.updateUser(id, username, role);
        res.json(createResponse(true, 'User updated successfully'));
    } catch (error) {
        console.error(error);
        res.status(500).json(createResponse(false, 'Failed to update user', null, error.message));
    }
};
