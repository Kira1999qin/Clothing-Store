const productModel = require('../models/productModel');

// Lấy danh sách sản phẩm
exports.getProducts = async (req, res) => {
    try {
        const products = await productModel.getProducts();

        const formattedProducts = products.map(product => ({
            id: product[0],
            name: product[1],
            price: product[2],
            type: product[3],
            gender: product[4],
            brand: product[5],
            image_url: product[6] || "https://endlessicons.com/wp-content/uploads/2012/11/image-holder-icon-614x460.png",
            quantity: product[7]
        }));

        res.json({
            success: true,
            message: 'Products fetched successfully',
            data: formattedProducts
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch products',
            error: error.message
        });
    }
};

// Thêm sản phẩm
exports.addProduct = async (req, res) => {
    const { name, price, type, gender, brand, imageUrl, quantity } = req.body;

    try {
        await productModel.addProduct(name, price, type, gender.trim(), brand, imageUrl, quantity);
        res.json({ success: true, message: 'Product added successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            success: false,
            message: 'Failed to add product',
            error: error.message
        });
    }
};

// Cập nhật sản phẩm
exports.updateProduct = async (req, res) => {
    const { id } = req.params;
    const { name, price, type, gender, brand, imageUrl, quantity } = req.body;
    try {
        await productModel.updateProduct(id, name, price, type, gender, brand, imageUrl, quantity);
        res.json({ success: true, message: 'Product updated successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            success: false,
            message: 'Failed to update product',
            error: error.message
        });
    }
};

// Xóa sản phẩm
exports.deleteProduct = async (req, res) => {
    const { id } = req.params;
    try {
        await productModel.deleteProduct(id);
        res.json({ success: true, message: 'Product deleted successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            success: false,
            message: 'Failed to delete product',
            error: error.message
        });
    }
};
