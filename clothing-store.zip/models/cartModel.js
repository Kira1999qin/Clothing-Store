const db = require('./db');
const oracledb = require('oracledb');




// Thêm sản phẩm vào giỏ hàng
exports.addToCart = async (userId, productId, quantity) => {
    await db.execute(
        `INSERT INTO CART (USER_ID, PRODUCT_ID, QUANTITY) 
         VALUES (:userId, :productId, :quantity)`,
        { userId, productId, quantity },
        { autoCommit: true }
    );
};

// Cập nhật số lượng sản phẩm trong giỏ hàng
exports.updateCartQuantity = async (cartId, quantity) => {
    await db.execute(
        `UPDATE CART 
         SET QUANTITY = :quantity 
         WHERE ID = :cartId`,
        { cartId, quantity },
        { autoCommit: true }
    );
};

// Tải giỏ hàng theo userId
// Tải danh sách sản phẩm trong giỏ hàng theo userId
exports.getCartByUserId = async (userId) => {
    const result = await db.execute(
        `SELECT 
            C.ID AS CART_ID, 
            P.ID AS PRODUCT_ID,
            P.NAME AS PRODUCT_NAME,
            P.PRICE AS PRODUCT_PRICE,
            P.IMAGE_URL AS PRODUCT_IMAGE,
            C.QUANTITY AS QUANTITY,
            (C.QUANTITY * P.PRICE) AS TOTAL
         FROM CART C
         JOIN PRODUCTS P ON C.PRODUCT_ID = P.ID
         WHERE C.USER_ID = :userId`,
        { userId }
    );
    return result.rows.map(row => ({
        cartId: row[0],
        productId: row[1],
        productName: row[2],
        productPrice: row[3],
        productImage: row[4] || "https://endlessicons.com/wp-content/uploads/2012/11/image-holder-icon-614x460.png", // Hình ảnh mặc định nếu không có
        quantity: row[5],
        total: row[6]
    }));
};


// Xóa sản phẩm khỏi giỏ hàng
exports.deleteCartItem = async (cartId) => {
    await db.execute(
        `DELETE FROM CART 
         WHERE ID = :cartId`,
        { cartId },
        { autoCommit: true }
    );
};

// Xóa toàn bộ giỏ hàng sau khi thanh toán
exports.checkout = async (userId) => {
    const connection = await db.getConnection();
    try {
        // Lấy danh sách sản phẩm trong giỏ hàng
        const cartItems = await connection.execute(
            `SELECT C.ID AS CART_ID, C.PRODUCT_ID, C.QUANTITY, P.PRICE, P.QUANTITY AS STOCK
             FROM CART C
             JOIN PRODUCTS P ON C.PRODUCT_ID = P.ID
             WHERE C.USER_ID = :userId`,
            { userId }
        );

        if (cartItems.rows.length === 0) {
            throw new Error('Giỏ hàng trống!');
        }

        // Kiểm tra số lượng hàng tồn kho
        for (const item of cartItems.rows) {
            const [cartId, productId, quantity, price, stock] = item;
            if (stock < quantity) {
                throw new Error(`Sản phẩm ID ${productId} không đủ hàng. Còn lại ${stock} sản phẩm.`);
            }
        }

        // Tính tổng tiền
        const totalAmount = cartItems.rows.reduce((sum, item) => sum + item[2] * item[3], 0);

        // Tạo đơn hàng trong bảng `ORDERS`
        const orderResult = await connection.execute(
            `INSERT INTO ORDERS (USER_ID, TOTAL_AMOUNT) 
             VALUES (:userId, :totalAmount) RETURNING ID INTO :orderId`,
            {
                userId,
                totalAmount,
                orderId: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER }
            },
            { autoCommit: false }
        );

        const orderId = orderResult.outBinds.orderId[0];

        // Lưu chi tiết đơn hàng và cập nhật số lượng
        for (const item of cartItems.rows) {
            const [cartId, productId, quantity, price] = item;

            await connection.execute(
                `INSERT INTO ORDER_DETAILS (ORDER_ID, PRODUCT_ID, QUANTITY, PRICE) 
                 VALUES (:orderId, :productId, :quantity, :price)`,
                { orderId, productId, quantity, price },
                { autoCommit: false }
            );

            await connection.execute(
                `UPDATE PRODUCTS 
                 SET QUANTITY = QUANTITY - :quantity 
                 WHERE ID = :productId`,
                { quantity, productId },
                { autoCommit: false }
            );
        }

        // Xóa giỏ hàng
        await connection.execute(
            `DELETE FROM CART WHERE USER_ID = :userId`,
            { userId },
            { autoCommit: false }
        );

        // Commit giao dịch
        await connection.commit();

        return {
            success: true,
            message: 'Checkout thành công!',
            orderId,
            totalAmount
        };
    } catch (error) {
        await connection.rollback();
        throw new Error(`Checkout thất bại: ${error.message}`);
    } finally {
        await connection.close();
    }
};


exports.getRevenue = async () => {
    const result = await db.execute(
        `SELECT 
            TO_CHAR(CREATED_AT, 'DD/MM/YYYY') AS ORDER_DATE,
            SUM(TOTAL_AMOUNT) AS TOTAL_AMOUNT
         FROM ORDERS
         GROUP BY TO_CHAR(CREATED_AT, 'DD/MM/YYYY')
         ORDER BY TO_CHAR(CREATED_AT, 'DD/MM/YYYY')`
    );
    return result.rows.map(row => ({
        orderDate: row[0],
        totalAmount: row[1]
    }));
};


