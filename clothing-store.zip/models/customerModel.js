const db = require('./db');

exports.register = async (username, password) => {
    await db.execute(
        'INSERT INTO USERS (USERNAME, PASSWORD, ROLE) VALUES (:username, :password, \'Customer\')',
        { username, password },
        { autoCommit: true }
    );
};

exports.login = async (username, password) => {
    const result = await db.execute(
        'SELECT * FROM USERS WHERE USERNAME = :username AND PASSWORD = :password ',
        { username, password }
    );
    return result.rows[0];
};

exports.getProducts = async () => {
    const result = await db.execute('SELECT * FROM PRODUCTS');
    return result.rows;
};

exports.addToCart = async (userId, productId, quantity) => {
    await db.execute(
        'INSERT INTO CART (USER_ID, PRODUCT_ID, QUANTITY) VALUES (:userId, :productId, :quantity)',
        { userId, productId, quantity },
        { autoCommit: true }
    );
};

exports.checkout = async (userId) => {
    const result = await db.execute(
        'SELECT C.PRODUCT_ID, P.NAME, C.QUANTITY, P.PRICE, (C.QUANTITY * P.PRICE) AS TOTAL\n' +
        'FROM CART C JOIN PRODUCTS P ON C.PRODUCT_ID = P.ID\n' +
        'WHERE C.USER_ID = :userId',
        { userId }
    );
    await db.execute('DELETE FROM CART WHERE USER_ID = :userId', { userId }, { autoCommit: true });
    return result.rows;
};
