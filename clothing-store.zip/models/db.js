const oracledb = require('oracledb');

const dbConfig = {
    user: 'admin', // Tài khoản Oracle
    password: 'admin', // Mật khẩu
    connectString: '222.255.238.175:1521/clothesdb', // Chuỗi kết nối
};

let pool;

// Khởi tạo kết nối pool
async function initialize() {
    try {
        pool = await oracledb.createPool(dbConfig);
        console.log('Connected to Oracle Database');

    } catch (err) {
        console.error('Error initializing database:', err);
        process.exit(1); // Dừng ứng dụng nếu lỗi xảy ra
    }
}


// Thực thi truy vấn
async function execute(query, binds = {}, options = {}) {
    let connection;
    try {
        connection = await pool.getConnection();
        const result = await connection.execute(query, binds, options);
        return result;
    } finally {
        if (connection) {
            await connection.close();
        }
    }
}

// Đóng kết nối pool
async function close() {
    await pool.close();
    console.log('Oracle pool closed');
}

module.exports = {
    initialize, execute, close,
    getConnection: async () => await pool.getConnection(),
};
