const db = require('./db');

// Lấy danh sách người dùng
exports.getUsers = async () => {
    const result = await db.execute('SELECT ID, USERNAME, ROLE FROM USERS');
    return result.rows;
};

// Kiểm tra username đã tồn tại
exports.isUsernameExists = async (username) => {
    const result = await db.execute(
        'SELECT COUNT(*) AS COUNT FROM USERS WHERE USERNAME = :username',
        { username }
    );
    return result.rows[0].COUNT > 0; // Trả về true nếu username đã tồn tại
};

// Thêm người dùng
exports.addUser = async (username, password, role) => {
    // Kiểm tra username đã tồn tại
    const exists = await this.isUsernameExists(username);
    if (exists) {
        throw new Error('Username already exists'); // Ném lỗi nếu username đã tồn tại
    }

    // Thêm người dùng mới
    await db.execute(
        'INSERT INTO USERS (USERNAME, PASSWORD, ROLE) VALUES (:username, :password, :role)',
        { username, password, role },
        { autoCommit: true }
    );
};

// Xóa người dùng
exports.deleteUser = async (id) => {
    await db.execute(
        'DELETE FROM USERS WHERE ID = :id',
        { id },
        { autoCommit: true }
    );
};

// Cập nhật người dùng
exports.updateUser = async (id, username, role) => {
    // Kiểm tra username đã tồn tại cho user khác
    const result = await db.execute(
        'SELECT ID FROM USERS WHERE USERNAME = :username AND ID != :id',
        { username, id }
    );
    if (result.rows.length > 0) {
        throw new Error('Username already exists'); // Ném lỗi nếu username đã tồn tại cho user khác
    }

    // Cập nhật người dùng
    await db.execute(
        'UPDATE USERS SET USERNAME = :username, ROLE = :role WHERE ID = :id',
        { id, username, role },
        { autoCommit: true }
    );
};

