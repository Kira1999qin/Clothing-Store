const db = require('./db');

// Lấy danh sách sản phẩm
exports.getProducts = async () => {
    const result = await db.execute(
        'SELECT id, name, price, type, gender, brand, image_url, quantity FROM products'
    );
    return result.rows;
};

// Thêm sản phẩm
exports.addProduct = async (name, price, type, gender, brand, imageUrl, quantity) => {
    await db.execute(
        'INSERT INTO products (name, price, type, gender, brand, image_url, quantity) VALUES (:name, :price, :type, :gender, :brand, :imageUrl, :quantity)',
        { name, price, type, gender, brand, imageUrl, quantity },
        { autoCommit: true }
    );
};

// Cập nhật sản phẩm
exports.updateProduct = async (id, name, price, type, gender, brand, imageUrl, quantity) => {
    await db.execute(
        'UPDATE products SET name = :name, price = :price, type = :type, gender = :gender, brand = :brand, image_url = :imageUrl, quantity = :quantity WHERE id = :id',
        { id, name, price, type, gender, brand, imageUrl, quantity },
        { autoCommit: true }
    );
};

// Xóa sản phẩm
exports.deleteProduct = async (id) => {
    await db.execute(
        'DELETE FROM products WHERE id = :id',
        { id },
        { autoCommit: true }
    );
};
