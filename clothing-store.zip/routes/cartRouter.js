const express = require('express');
const router = express.Router();
const cartController = require('../controllers/cartController');

// Thêm sản phẩm vào giỏ hàng
router.post('/add', cartController.addToCart);

// Cập nhật số lượng sản phẩm trong giỏ hàng
router.put('/update', cartController.updateCartQuantity);

// Lấy danh sách giỏ hàng theo userId
router.get('/:userId', cartController.getCartByUserId);

// Xóa sản phẩm khỏi giỏ hàng
router.delete('/:cartId', cartController.deleteCartItem);

// Thanh toán
router.post('/checkout', cartController.checkout);

router.get('/order/revenue', cartController.getRevenueStatistics);


module.exports = router;
