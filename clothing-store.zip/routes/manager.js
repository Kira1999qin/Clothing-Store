const express = require('express');
const router = express.Router();
const managerController = require('../controllers/managerController');

router.get('/users', managerController.getUsers); // Lấy danh sách người dùng
router.post('/users', managerController.addUser); // Thêm người dùng mới
router.put('/users/:id', managerController.updateUser); // Cập nhật thông tin người dùng
router.delete('/users/:id', managerController.deleteUser); // Xóa người dùng


module.exports = router;
